SEXP savvy_compile__ffi(SEXP c_arg__prql_query, SEXP c_arg__target, SEXP c_arg__format, SEXP c_arg__signature_comment, SEXP c_arg__display);
SEXP savvy_compiler_version__ffi(void);
SEXP savvy_pl_to_rq__ffi(SEXP c_arg__pl_json);
SEXP savvy_prql_get_targets__ffi(void);
SEXP savvy_prql_to_pl__ffi(SEXP c_arg__prql_query);
SEXP savvy_rq_to_sql__ffi(SEXP c_arg__rq_json);
