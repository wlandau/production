library(testthat)
library(multitools)

test_check("multitools")
