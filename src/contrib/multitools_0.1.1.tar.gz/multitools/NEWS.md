# multitools 0.1.1

* Aligns with R-Multiverse infrastructure.

# multitools 0.1.0

* Rename package.

# releases 0.0.4

* First version.
