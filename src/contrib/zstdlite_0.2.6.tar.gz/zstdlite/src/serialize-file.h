
SEXP zstd_serialize_stream_file_(SEXP robj, SEXP file_, SEXP cctx_, SEXP opts_);
SEXP zstd_unserialize_stream_file_(SEXP src_, SEXP dctx_, SEXP opts_);
