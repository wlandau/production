unsigned char *read_file(const char *filename, size_t *src_size); 
