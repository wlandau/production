#ifndef UNIGD_VERSION
#define UNIGD_VERSION "0.1.0.9000"
#endif
