#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom utils getFromNamespace
## usethis namespace: end
NULL
