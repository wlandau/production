# Version 0.0.1

* Add RStudio addin (#8, @parmsam)
* Add button to add a new target into _targets.R (#9, @parmsam)
* Highlight graph target on manifest row select (#10, @parmsam)
* Add button to reset Graph card view (#11, @parmsam)
* Add navigation buttons to Graph card (@parmsam)
* Add button to copy _targets.R script (#15, @parmsam)
* Add _targets.R saving and loading using shinyFiles package (#25, @parmsam)
* Add argument into targetsketch() to load _targets.R script of interest (#27, @parmsam)

# Version 0.0.0.9000

* First version
