# write_json: path works

    Code
      cat(readLines(path, warn = FALSE), sep = "\n")
    Output
      {"columns":[{"name":"mpg","datatype":"Float64","bit_settings":"","values":[21.0,21.0,22.8,21.4,18.7]},{"name":"cyl","datatype":"Float64","bit_settings":"","values":[6.0,6.0,4.0,6.0,8.0]},{"name":"disp","datatype":"Float64","bit_settings":"","values":[160.0,160.0,108.0,258.0,360.0]}]}

