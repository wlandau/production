# print polars_info()

    Code
      info
    Output
      Polars R package version : 999.999.999
      Rust Polars crate version: 999.999.999
      
      Thread pool size: 1 
      
      Features:                               
      default                   FALSE
      full_features             FALSE
      disable_limit_max_threads FALSE
      nightly                   FALSE
      sql                       FALSE
      rpolars_debug_print       FALSE
      
      Code completion: deactivated 

