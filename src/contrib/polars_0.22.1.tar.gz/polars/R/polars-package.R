#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom stats na.omit median
#' @importFrom utils .DollarNames globalVariables getFromNamespace head tail download.file capture.output str
#' @importFrom methods new
## usethis namespace: end
NULL

utils::globalVariables(c("pl", "self", "runtime_state", "build_debug_print"))
