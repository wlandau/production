## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

rust_toolchain_version = read.dcf(
  system.file("DESCRIPTION", package = "polars"),
  fields = "Config/polars/RustToolchainVersion", all = TRUE
)[1, 1]

## -----------------------------------------------------------------------------
library(polars)
polars_info()

