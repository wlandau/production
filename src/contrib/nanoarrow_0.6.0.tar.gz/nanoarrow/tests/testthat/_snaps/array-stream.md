# as_nanoarrow_array_stream() works for nanoarrow_array_stream

    is.null(schema) is not TRUE

# as_nanoarrow_array_stream() works for nanoarrow_array

    is.null(schema) is not TRUE

