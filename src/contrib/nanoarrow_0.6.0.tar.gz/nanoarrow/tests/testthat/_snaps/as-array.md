# as_nanoarrow_array() errors for bad logical() creation

    Invalid: Expecting a character vector

# as_nanoarrow_array() errors for bad data.frame() -> na_struct()

    Can't create Array<int32()> from object of type data.frame

# as_nanoarrow_array() works for bad unspecified() create

    NotImplemented: day_time_interval

