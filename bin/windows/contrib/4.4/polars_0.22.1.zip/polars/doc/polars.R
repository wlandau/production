## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## -----------------------------------------------------------------------------
library(polars)

pl$Series(name = "a", values = (1:5) * 5)

pl$DataFrame(a = 1:5, b = letters[1:5])

## -----------------------------------------------------------------------------
ser = as_polars_series((1:5) * 5)
ser

dat = as_polars_df(mtcars)
dat

## -----------------------------------------------------------------------------
pl$DataFrame(
  a = as_polars_series((1:5) * 5),
  b = as_polars_series(letters[1:5]),
  c = as_polars_series(c(1, 2, 3, 4, 5)),
  d = c(15, 14, 13, 12, 11),
  c(5, 4, 3, 2, 1),
  1:5
)

## -----------------------------------------------------------------------------
# Series
length(ser)

max(ser)

# DataFrame
dat[c(1:3, 12), c("mpg", "hp")]

names(dat)

dim(dat)

head(dat, n = 2)

## -----------------------------------------------------------------------------
ser$sort()

## -----------------------------------------------------------------------------
ser$max()

dat$slice(offset = 2, length = 3)

## -----------------------------------------------------------------------------
dat$max()

## -----------------------------------------------------------------------------
dat$tail(10)$max()

## -----------------------------------------------------------------------------
dat$tail(10)$max() |>
  as.data.frame()

## -----------------------------------------------------------------------------
dat$group_by("cyl")$mean()

## -----------------------------------------------------------------------------
dat$filter(pl$col("cyl") == 6)

dat$filter(pl$col("cyl") == 6 & pl$col("am") == 1)

dat$select(pl$col(c("mpg", "hp")))

## -----------------------------------------------------------------------------
dat$filter(
  pl$col("cyl") == 6
)$select(
  pl$col(c("mpg", "hp", "cyl"))
)

## -----------------------------------------------------------------------------
# Add the grouped sums of some selected columns.
dat$with_columns(
  pl$col("mpg")$sum()$over("cyl")$alias("sum_mpg"),
  pl$col("hp")$sum()$over("cyl")$alias("sum_hp")
)

## -----------------------------------------------------------------------------
dat$with_columns(
  pl$col(c("mpg", "hp"))$sum()$over("cyl")$name$prefix("sum_")
)

## -----------------------------------------------------------------------------
dat$group_by(
  "cyl",
  maintain_order = TRUE
)$agg(
  pl$col(c("mpg", "hp"))$sum()
)

## -----------------------------------------------------------------------------
dat$group_by(
  "cyl",
  manual = pl$col("am")$cast(pl$Boolean)
)$agg(
  mean_mpg = pl$col("mpg")$mean(),
  med_hp = pl$col("hp")$median()
)

## -----------------------------------------------------------------------------
indo = as_polars_df(Indometh)
indo

## -----------------------------------------------------------------------------
indo_wide = indo$pivot(values = "conc", index = "time", on = "Subject")
indo_wide

## -----------------------------------------------------------------------------
# indo_wide$melt(id_vars = "time") # default column names are "variable" and "value"
indo_wide$unpivot(index = "time", variable_name = "subject", value_name = "conc")

## -----------------------------------------------------------------------------
dat$pivot(
  values = "mpg",
  index = c("am", "vs"),
  on = "cyl",
  aggregate_function = "median" # aggregating function
)

## -----------------------------------------------------------------------------
data("flights", "planes", package = "nycflights13")
flights = as_polars_df(flights)
planes = as_polars_df(planes)

flights$join(
  planes,
  on = "tailnum",
  how = "left"
)

## -----------------------------------------------------------------------------
ldat = dat$lazy()
ldat

## -----------------------------------------------------------------------------
as_polars_lf(dat)

## -----------------------------------------------------------------------------
subset_query = ldat$filter(
  pl$col("cyl") == 6
)$select(
  pl$col(c("mpg", "hp", "cyl"))
)

subset_query

## -----------------------------------------------------------------------------
cat(subset_query$explain())

## -----------------------------------------------------------------------------
subset_query$collect()

## -----------------------------------------------------------------------------
write.csv(airquality, "airquality.csv", row.names = FALSE)

pl$read_csv("airquality.csv")

## -----------------------------------------------------------------------------
pl$scan_csv("airquality.csv")

## -----------------------------------------------------------------------------
as_polars_df(airquality)$write_parquet("airquality.parquet")

# eager version (okay)
aq_collected = pl$read_parquet("airquality.parquet")

# lazy version (better)
aq = pl$scan_parquet("airquality.parquet")

aq$filter(
  pl$col("Month") <= 6
)$group_by(
  "Month"
)$agg(
  pl$col(c("Ozone", "Temp"))$mean()
)$collect()

## ----eval=(requireNamespace("arrow", quietly = TRUE) && arrow::arrow_with_dataset())----
dir.create("airquality-ds")

# Create a hive-partitioned dataset with the function from the arrow package
arrow::write_dataset(airquality, "airquality-ds", partitioning = "Month")

# Use pattern globbing to scan all parquet files in the folder
aq2 = pl$scan_parquet("airquality-ds/**/*.parquet")

# Scan the first two rows
aq2$fetch(2)

## -----------------------------------------------------------------------------
# Remove LazyFrames which reference the files
rm(aq, aq2)

file.remove(c("airquality.csv", "airquality.parquet"))
unlink("airquality-ds", recursive = TRUE)

## -----------------------------------------------------------------------------
as_polars_df(iris)$select(
  pl$col("Sepal.Length")$map_batches(\(s) { # map with a R function
    x = as.vector(s) # convert from Polars Series to a native R vector
    x[x >= 5] = 10
    x[1:10] # if return is R vector, it will automatically be converted to Polars Series again
  })
) |>
  as.data.frame()

## -----------------------------------------------------------------------------
pl$dtypes$Float64

